from .encoder import TSEncoder
from .encoder import DCNN
